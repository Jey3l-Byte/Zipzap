CREATE DATABASE IF NOT EXISTS university_car_pass
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE university_car_pass;

CREATE TABLE IF NOT EXISTS tbl_users (
    idnum INT UNSIGNED NOT NULL AUTO_INCREMENT,
    full_name VARCHAR(120) NOT NULL,
    university_id VARCHAR(40) NULL,
    email VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('student', 'admin', 'guard') NOT NULL DEFAULT 'student',
    verification_status ENUM('Pending', 'Verified', 'Rejected') NOT NULL DEFAULT 'Pending',
    verified_by INT UNSIGNED NULL,
    verified_at DATETIME NULL,
    verification_note VARCHAR(500) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (idnum),
    UNIQUE KEY uq_users_email (email),
    UNIQUE KEY uq_users_university_id (university_id),
    KEY idx_users_verification (role, verification_status),
    CONSTRAINT fk_user_verifier FOREIGN KEY (verified_by) REFERENCES tbl_users(idnum)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tbl_vehicles (
    idnum INT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_id INT UNSIGNED NOT NULL,
    plate_number VARCHAR(20) NOT NULL,
    vehicle_type ENUM('Motorcycle', 'Car', 'Van', 'Pickup', 'Other') NOT NULL,
    make_model VARCHAR(100) NOT NULL,
    color VARCHAR(40) NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') NOT NULL DEFAULT 'Pending',
    review_note VARCHAR(500) NULL,
    reviewed_by INT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (idnum),
    UNIQUE KEY uq_vehicle_plate (plate_number),
    KEY idx_vehicle_owner (owner_id),
    KEY idx_vehicle_status (status),
    CONSTRAINT fk_vehicle_owner FOREIGN KEY (owner_id) REFERENCES tbl_users(idnum),
    CONSTRAINT fk_vehicle_reviewer FOREIGN KEY (reviewed_by) REFERENCES tbl_users(idnum)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tbl_car_logs (
    idnum BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    vehicle_id INT UNSIGNED NOT NULL,
    time_in DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    time_out DATETIME NULL,
    guard_in_id INT UNSIGNED NOT NULL,
    guard_out_id INT UNSIGNED NULL,
    entry_note VARCHAR(500) NULL,
    PRIMARY KEY (idnum),
    KEY idx_log_vehicle (vehicle_id),
    KEY idx_log_time_in (time_in),
    KEY idx_log_open (vehicle_id, time_out),
    CONSTRAINT fk_log_vehicle FOREIGN KEY (vehicle_id) REFERENCES tbl_vehicles(idnum),
    CONSTRAINT fk_log_guard_in FOREIGN KEY (guard_in_id) REFERENCES tbl_users(idnum),
    CONSTRAINT fk_log_guard_out FOREIGN KEY (guard_out_id) REFERENCES tbl_users(idnum)
) ENGINE=InnoDB;
