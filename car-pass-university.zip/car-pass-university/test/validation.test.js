const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizePlate, validEmail, validPassword, validVehicle } = require('../lib/validation');

test('normalizes plate numbers to uppercase and removes spaces', () => {
    assert.equal(normalizePlate(' ab  c-123 '), 'ABC-123');
});
test('accepts valid email and rejects malformed email', () => {
    assert.equal(validEmail('student@example.edu'), true);
    assert.equal(validEmail('not-an-email'), false);
});
test('password must be at least 10 characters and no more than 72', () => {
    assert.equal(validPassword('a-secure-password'), true);
    assert.equal(validPassword('short'), false);
    assert.equal(validPassword('x'.repeat(73)), false);
});
test('accepts a valid vehicle and normalizes its plate', () => {
    const result = validVehicle({ plate_number: 'abc-123', vehicle_type: 'Car', make_model: 'Toyota Vios', color: 'White' });
    assert.equal(result.ok, true);
    assert.equal(result.value.plate_number, 'ABC-123');
});
test('rejects invalid plate numbers and vehicle types', () => {
    assert.equal(validVehicle({ plate_number: '!!!', vehicle_type: 'Car', make_model: 'Toyota', color: 'Red' }).ok, false);
    assert.equal(validVehicle({ plate_number: 'ABC123', vehicle_type: 'Spaceship', make_model: 'Model X', color: 'Blue' }).ok, false);
});
