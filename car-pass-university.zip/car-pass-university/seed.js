require('dotenv').config();
const bcrypt = require('bcryptjs');
const mysql = require('mysql');

const conn = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'university_car_pass'
});

function upsertAccount(name, email, password, role) {
    return new Promise((resolve, reject) => {
        if (!name || !email || !password || password.length < 10) {
            return reject(new Error(`${role} seed values are missing or password is shorter than 10 characters.`));
        }
        const hash = bcrypt.hashSync(password, 12);
        const sql = `INSERT INTO tbl_users (full_name, email, password_hash, role)
                     VALUES (?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE full_name = VALUES(full_name),
                     password_hash = VALUES(password_hash), role = VALUES(role)`;
        conn.query(sql, [name, email.toLowerCase(), hash, role], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

async function main() {
    await upsertAccount(process.env.ADMIN_NAME, process.env.ADMIN_EMAIL, process.env.ADMIN_PASSWORD, 'admin');
    await upsertAccount(process.env.GUARD_NAME, process.env.GUARD_EMAIL, process.env.GUARD_PASSWORD, 'guard');
    console.log('Admin and guard accounts are ready. Change the example passwords before real use.');
}
main()
    .catch((err) => {
        console.error('Seeding failed:', err.message);
        process.exitCode = 1;
    })
    .finally(() => conn.end());
