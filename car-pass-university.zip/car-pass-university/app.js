require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const conn = require('./conn');
const { cleanText, normalizePlate, validEmail, validPassword, validVehicle } = require('./lib/validation');

const app = express();
const PORT = Number(process.env.PORT) || 5000;

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(helmet({ contentSecurityPolicy: false })); // CSP is disabled for the simple inline-style EJS templates.
app.use(express.static(__dirname + '/public'));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use(session({
    name: 'carpass.sid',
    secret: process.env.SESSION_SECRET || 'development-only-change-this-secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: 'lax',
        secure: process.env.NODE_ENV === 'production',
        maxAge: 1000 * 60 * 60 * 4
    }
}));

app.use((req, res, next) => {
    res.locals.currentUser = req.session.user || null;
    res.locals.notice = req.session.notice || null;
    delete req.session.notice;
    next();
});

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const query = (sql, params = []) => new Promise((resolve, reject) => {
    conn.query(sql, params, (err, result) => err ? reject(err) : resolve(result));
});
const flash = (req, type, message) => { req.session.notice = { type, message }; };
const redirectWithMessage = (req, res, path, type, message) => {
    flash(req, type, message);
    return res.redirect(path);
};

function requireAuth(req, res, next) {
    if (!req.session.user) return res.redirect('/login');
    next();
}
function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.session.user) return res.redirect('/login');
        if (!roles.includes(req.session.user.role)) return res.status(403).render('error', { message: 'You do not have permission to access this page.' });
        next();
    };
}
function asyncRoute(handler) {
    return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

app.get('/', (req, res) => {
    if (!req.session.user) return res.render('home');
    const destinations = { student: '/student/dashboard', admin: '/admin/dashboard', guard: '/guard/check' };
    return res.redirect(destinations[req.session.user.role] || '/login');
});

app.get('/register', (req, res) => {
    if (req.session.user) return res.redirect('/');
    res.render('register', { values: {} });
});
app.post('/register', loginLimiter, asyncRoute(async (req, res) => {
    const fullName = cleanText(req.body.full_name, 120);
    const universityId = cleanText(req.body.university_id, 40);
    const email = cleanText(req.body.email, 190).toLowerCase();
    const password = req.body.password;
    if (fullName.length < 2 || universityId.length < 2 || !validEmail(email) || !validPassword(password)) {
        return res.status(400).render('register', {
            values: { full_name: fullName, university_id: universityId, email },
            error: 'Enter your name, university ID, a valid email, and a password of at least 10 characters.'
        });
    }
    try {
        await query(
            'INSERT INTO tbl_users (full_name, university_id, email, password_hash, role, verification_status) VALUES (?, ?, ?, ?, ?, ?)',
            [fullName, universityId, email, bcrypt.hashSync(password, 12), 'student', 'Pending']
        );
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).render('register', { values: { full_name: fullName, university_id: universityId, email }, error: 'That email or university ID is already registered.' });
        }
        throw err;
    }
    return redirectWithMessage(req, res, '/login', 'success', 'Account created. You can now log in.');
}));

app.get('/login', (req, res) => {
    if (req.session.user) return res.redirect('/');
    res.render('login', { email: '' });
});
app.post('/login', loginLimiter, asyncRoute(async (req, res) => {
    const email = cleanText(req.body.email, 190).toLowerCase();
    const password = req.body.password;
    if (!validEmail(email) || typeof password !== 'string' || password.length > 72) {
        return res.status(400).render('login', { email, error: 'Enter a valid email and password.' });
    }
    const rows = await query('SELECT idnum, full_name, university_id, email, password_hash, role, verification_status FROM tbl_users WHERE email = ? LIMIT 1', [email]);
    const user = rows[0];
    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
        return res.status(401).render('login', { email, error: 'Incorrect email or password.' });
    }
    req.session.regenerate((err) => {
        if (err) return res.status(500).render('error', { message: 'Could not start a session. Please try again.' });
        req.session.user = { idnum: user.idnum, full_name: user.full_name, university_id: user.university_id, email: user.email, role: user.role, verification_status: user.verification_status };
        const destinations = { student: '/student/dashboard', admin: '/admin/dashboard', guard: '/guard/check' };
        return res.redirect(destinations[user.role] || '/login');
    });
}));
app.post('/logout', requireAuth, (req, res) => {
    req.session.destroy(() => res.redirect('/'));
});

app.get('/student/dashboard', requireRole('student'), asyncRoute(async (req, res) => {
    const accountRows = await query("SELECT verification_status, verification_note FROM tbl_users WHERE idnum = ? AND role = 'student' LIMIT 1", [req.session.user.idnum]);
    const account = accountRows[0] || { verification_status: 'Pending', verification_note: null };
    req.session.user.verification_status = account.verification_status;
    const vehicles = await query('SELECT * FROM tbl_vehicles WHERE owner_id = ? ORDER BY created_at DESC', [req.session.user.idnum]);
    res.render('student-dashboard', { vehicles, account });
}));
app.get('/student/vehicles/new', requireRole('student'), asyncRoute(async (req, res) => {
    const rows = await query("SELECT verification_status FROM tbl_users WHERE idnum = ? AND role = 'student' LIMIT 1", [req.session.user.idnum]);
    if (!rows[0] || rows[0].verification_status !== 'Verified') return redirectWithMessage(req, res, '/student/dashboard', 'error', 'Your university ID must be verified by an admin before you can register a vehicle.');
    res.render('vehicle-form', { values: {}, formAction: '/student/vehicles', isEdit: false });
}));
app.post('/student/vehicles', requireRole('student'), asyncRoute(async (req, res) => {
    const verification = await query("SELECT verification_status FROM tbl_users WHERE idnum = ? AND role = 'student' LIMIT 1", [req.session.user.idnum]);
    if (!verification[0] || verification[0].verification_status !== 'Verified') return redirectWithMessage(req, res, '/student/dashboard', 'error', 'Your university ID must be verified by an admin before you can register a vehicle.');
    const result = validVehicle(req.body);
    if (!result.ok) return res.status(400).render('vehicle-form', { values: req.body, formAction: '/student/vehicles', isEdit: false, error: result.error });
    try {
        await query(
            'INSERT INTO tbl_vehicles (owner_id, plate_number, vehicle_type, make_model, color) VALUES (?, ?, ?, ?, ?)',
            [req.session.user.idnum, result.value.plate_number, result.value.vehicle_type, result.value.make_model, result.value.color]
        );
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') return res.status(409).render('vehicle-form', { values: req.body, formAction: '/student/vehicles', isEdit: false, error: 'That plate number is already registered.' });
        throw err;
    }
    redirectWithMessage(req, res, '/student/dashboard', 'success', 'Vehicle submitted for admin review.');
}));

app.get('/student/vehicles/:id/edit', requireRole('student'), asyncRoute(async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(404).render('error', { message: 'Vehicle not found.' });
    const rows = await query('SELECT * FROM tbl_vehicles WHERE idnum = ? AND owner_id = ? LIMIT 1', [id, req.session.user.idnum]);
    if (!rows[0]) return res.status(404).render('error', { message: 'Vehicle not found or you do not own it.' });
    const active = await query('SELECT idnum FROM tbl_car_logs WHERE vehicle_id = ? AND time_out IS NULL LIMIT 1', [id]);
    if (active.length) return redirectWithMessage(req, res, '/student/dashboard', 'error', 'You cannot edit a vehicle while it is recorded inside campus.');
    const verified = await query('SELECT verification_status FROM tbl_users WHERE idnum = ? LIMIT 1', [req.session.user.idnum]);
    if (!verified[0] || verified[0].verification_status !== 'Verified') return redirectWithMessage(req, res, '/student/dashboard', 'error', 'Your university ID must be verified before editing vehicles.');
    res.render('vehicle-form', { values: rows[0], formAction: `/student/vehicles/${id}/edit`, isEdit: true });
}));
app.post('/student/vehicles/:id/edit', requireRole('student'), asyncRoute(async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(404).render('error', { message: 'Vehicle not found.' });
    const verified = await query('SELECT verification_status FROM tbl_users WHERE idnum = ? LIMIT 1', [req.session.user.idnum]);
    if (!verified[0] || verified[0].verification_status !== 'Verified') return redirectWithMessage(req, res, '/student/dashboard', 'error', 'Your university ID must be verified before editing vehicles.');
    const existing = await query('SELECT idnum, status FROM tbl_vehicles WHERE idnum = ? AND owner_id = ? LIMIT 1', [id, req.session.user.idnum]);
    if (!existing[0]) return res.status(404).render('error', { message: 'Vehicle not found or you do not own it.' });
    const active = await query('SELECT idnum FROM tbl_car_logs WHERE vehicle_id = ? AND time_out IS NULL LIMIT 1', [id]);
    if (active.length) return redirectWithMessage(req, res, '/student/dashboard', 'error', 'You cannot edit a vehicle while it is recorded inside campus.');
    const result = validVehicle(req.body);
    if (!result.ok) return res.status(400).render('vehicle-form', { values: req.body, formAction: `/student/vehicles/${id}/edit`, isEdit: true, error: result.error });
    try {
        const update = await query(
            `UPDATE tbl_vehicles SET plate_number = ?, vehicle_type = ?, make_model = ?, color = ?,
             status = 'Pending', review_note = NULL, reviewed_by = NULL, reviewed_at = NULL
             WHERE idnum = ? AND owner_id = ?`,
            [result.value.plate_number, result.value.vehicle_type, result.value.make_model, result.value.color, id, req.session.user.idnum]
        );
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') return res.status(409).render('vehicle-form', { values: req.body, formAction: `/student/vehicles/${id}/edit`, isEdit: true, error: 'That plate number is already registered.' });
        throw err;
    }
    redirectWithMessage(req, res, '/student/dashboard', 'success', 'Vehicle details updated. Admin approval is required again.');
}));

app.get('/admin/dashboard', requireRole('admin'), asyncRoute(async (req, res) => {
    const pending = await query(
        `SELECT v.*, u.full_name AS owner_name, u.university_id, u.email
         FROM tbl_vehicles v JOIN tbl_users u ON u.idnum = v.owner_id
         WHERE v.status = 'Pending' ORDER BY v.created_at ASC`
    );
    const counts = await query(
        `SELECT status, COUNT(*) AS total FROM tbl_vehicles GROUP BY status`
    );
    const pendingStudents = await query(
        `SELECT idnum, full_name, university_id, email, created_at FROM tbl_users
         WHERE role = 'student' AND verification_status = 'Pending' ORDER BY created_at ASC`
    );
    res.render('admin-dashboard', { pending, counts, pendingStudents });
}));
app.post('/admin/students/:id/verify', requireRole('admin'), asyncRoute(async (req, res) => {
    const id = Number(req.params.id);
    const status = req.body.status;
    const note = cleanText(req.body.verification_note, 500);
    if (!Number.isSafeInteger(id) || id < 1 || !['Verified', 'Rejected'].includes(status)) {
        return redirectWithMessage(req, res, '/admin/dashboard', 'error', 'Invalid student verification request.');
    }
    const result = await query(
        `UPDATE tbl_users SET verification_status = ?, verification_note = ?, verified_by = ?, verified_at = NOW()
         WHERE idnum = ? AND role = 'student' AND verification_status = 'Pending'`,
        [status, note || null, req.session.user.idnum, id]
    );
    if (result.affectedRows === 0) return redirectWithMessage(req, res, '/admin/dashboard', 'error', 'Student account not found or already reviewed.');
    redirectWithMessage(req, res, '/admin/dashboard', 'success', `Student account ${status.toLowerCase()}.`);
}));

app.post('/admin/vehicles/:id/review', requireRole('admin'), asyncRoute(async (req, res) => {
    const id = Number(req.params.id);
    const status = req.body.status;
    const note = cleanText(req.body.review_note, 500);
    if (!Number.isSafeInteger(id) || id < 1 || !['Approved', 'Rejected'].includes(status)) {
        return redirectWithMessage(req, res, '/admin/dashboard', 'error', 'Invalid review request.');
    }
    const result = await query(
        `UPDATE tbl_vehicles SET status = ?, review_note = ?, reviewed_by = ?, reviewed_at = NOW()
         WHERE idnum = ? AND status = 'Pending'`,
        [status, note || null, req.session.user.idnum, id]
    );
    if (result.affectedRows === 0) return redirectWithMessage(req, res, '/admin/dashboard', 'error', 'This request no longer exists or has already been reviewed.');
    redirectWithMessage(req, res, '/admin/dashboard', 'success', `Vehicle request ${status.toLowerCase()}.`);
}));

app.get('/guard/check', requireRole('guard'), asyncRoute(async (req, res) => {
    const plate = normalizePlate(req.query.plate || '');
    let vehicle = null;
    let activeLog = null;
    let logs = [];
    if (plate) {
        const rows = await query(
            `SELECT v.*, u.full_name AS owner_name, u.university_id
             FROM tbl_vehicles v JOIN tbl_users u ON u.idnum = v.owner_id
             WHERE v.plate_number = ? LIMIT 1`, [plate]
        );
        vehicle = rows[0] || null;
        if (vehicle) {
            const active = await query(
                'SELECT * FROM tbl_car_logs WHERE vehicle_id = ? AND time_out IS NULL ORDER BY time_in DESC LIMIT 1',
                [vehicle.idnum]
            );
            activeLog = active[0] || null;
            logs = await query(
                `SELECT l.*, gi.full_name AS guard_in_name, go.full_name AS guard_out_name
                 FROM tbl_car_logs l
                 JOIN tbl_users gi ON gi.idnum = l.guard_in_id
                 LEFT JOIN tbl_users go ON go.idnum = l.guard_out_id
                 WHERE l.vehicle_id = ? ORDER BY l.time_in DESC LIMIT 10`, [vehicle.idnum]
            );
        }
    }
    res.render('guard-check', { plate, vehicle, activeLog, logs });
}));
app.post('/guard/vehicles/:id/entry', requireRole('guard'), asyncRoute(async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return redirectWithMessage(req, res, '/guard/check', 'error', 'Invalid vehicle ID.');
    const rows = await query('SELECT idnum, status, plate_number FROM tbl_vehicles WHERE idnum = ? LIMIT 1', [id]);
    if (!rows[0] || rows[0].status !== 'Approved') return redirectWithMessage(req, res, `/guard/check?plate=${encodeURIComponent(rows[0]?.plate_number || '')}`, 'error', 'Only approved vehicles may enter.');
    const active = await query('SELECT idnum FROM tbl_car_logs WHERE vehicle_id = ? AND time_out IS NULL LIMIT 1', [id]);
    if (active.length) return redirectWithMessage(req, res, `/guard/check?plate=${encodeURIComponent(rows[0].plate_number)}`, 'error', 'This vehicle already has an open entry record.');
    await query('INSERT INTO tbl_car_logs (vehicle_id, guard_in_id) VALUES (?, ?)', [id, req.session.user.idnum]);
    redirectWithMessage(req, res, `/guard/check?plate=${encodeURIComponent(rows[0].plate_number)}`, 'success', 'Vehicle entry recorded.');
}));
app.post('/guard/logs/:id/exit', requireRole('guard'), asyncRoute(async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return redirectWithMessage(req, res, '/guard/check', 'error', 'Invalid log ID.');
    const rows = await query(
        `SELECT l.idnum, v.plate_number FROM tbl_car_logs l JOIN tbl_vehicles v ON v.idnum = l.vehicle_id
         WHERE l.idnum = ? AND l.time_out IS NULL LIMIT 1`, [id]
    );
    if (!rows[0]) return redirectWithMessage(req, res, '/guard/check', 'error', 'This log is already closed or does not exist.');
    await query('UPDATE tbl_car_logs SET time_out = NOW(), guard_out_id = ? WHERE idnum = ? AND time_out IS NULL', [req.session.user.idnum, id]);
    redirectWithMessage(req, res, `/guard/check?plate=${encodeURIComponent(rows[0].plate_number)}`, 'success', 'Vehicle exit recorded.');
}));

app.use((req, res) => res.status(404).render('error', { message: 'Page not found.' }));
app.use((err, req, res, next) => {
    console.error(err.stack || err);
    if (res.headersSent) return next(err);
    res.status(500).render('error', { message: 'Something went wrong. Check the server terminal for details.' });
});

if (require.main === module) {
    app.listen(PORT, () => console.log(`Car Pass (University) running at http://localhost:${PORT}`));
}
module.exports = app;
