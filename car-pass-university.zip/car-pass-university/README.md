# Car Pass (University)

A starter web application for university vehicle registration, admin approval, and security-gate entry/exit logging. Built with Node.js, Express, EJS, MySQL, and CSS, following the same route/query pattern as the original student-registration project.

## Features

- Student self-registration and login
- Manual university ID verification by an administrator before a student can register vehicles
- Students submit vehicle applications and see Pending / Approved / Rejected status
- Students can edit their own vehicles; edits reset approval to Pending and are blocked while the vehicle is recorded inside campus
- Admin account reviews pending requests and adds an optional review note
- Guard account searches by plate number, verifies approval, records entry and exit
- Vehicle history shows the last 10 gate records
- Role-based route protection, hashed passwords, parameterized SQL, input validation, login rate limiting, Helmet security headers
- Starter unit tests for validation

## Requirements

- Node.js 18+ recommended
- MySQL 8+ (or a compatible MySQL server)
- npm

## Setup (local development)

1. For a fresh installation, create the database and tables by importing `schema.sql` in MySQL Workbench/phpMyAdmin, or run:

   ```sql
   SOURCE /full/path/to/schema.sql;
   ```

   The schema creates and selects `university_car_pass`.

   If you already created the earlier starter database before manual student verification was added, back it up and run `migrations/001_manual_student_verification.sql` exactly once instead of re-running the fresh schema. Existing student accounts will become Pending and must be verified manually. Do not run both the migration and fresh schema on the same existing tables.

2. Copy `.env.example` to `.env` and edit the database credentials and session secret. Do not commit `.env`.

3. Install packages:

   ```bash
   npm install
   ```

4. Create the admin and guard accounts:

   ```bash
   npm run seed
   ```

   The seed script reads credentials from `.env`. Change the example passwords before use. Run the seed script again to update the seeded accounts if you change their credentials in `.env`.

5. Start the app:

   ```bash
   npm start
   ```

6. Open `http://localhost:5000`.

## Default local demo accounts

These are only the defaults in `.env.example`, and they exist only after `npm run seed`:

- Admin: `admin@university.local` / `ChangeAdmin123!`
- Guard: `guard@university.local` / `ChangeGuard123!`

Change both passwords before using the app with real data. Student accounts are created through the registration page.

## Test

```bash
npm test
```

These tests cover input-validation helpers. They do not replace integration tests against a running MySQL server. To test the full app, use the manual checklist below.

## Manual end-to-end test checklist

1. Register a student account using `/register`; confirm the account is Pending verification.
2. Log in as that student and confirm the dashboard says the university ID needs manual verification and vehicle registration is unavailable.
3. Log out, log in as the admin, manually compare the student ID with the university-approved record, then verify the student. Also test rejecting a separate test account.
4. Log back in as the verified student and register a vehicle. Confirm it appears as Pending.
5. Log out, log in as the admin, approve the vehicle.
6. Log out, log in as the guard, search for the exact plate, and record entry.
7. Search again; confirm an open log is shown and the button is Record exit.
8. Record exit and confirm both timestamps appear in history.
9. Submit a second vehicle and reject it; verify the guard cannot record its entry.
10. Edit an owned vehicle and confirm its status resets to Pending. Confirm another student cannot edit that vehicle by changing the URL ID.
11. While a vehicle has an open gate log, attempt to edit it and confirm the app blocks the edit.
12. Try duplicate email, university ID, and plate number; each should show a useful message.
13. Try opening `/admin/dashboard` as a student; the app should return a 403 page.
14. Try a made-up URL; the app should return a 404 page.
15. From a second device on the trusted school LAN, open the host computer’s LAN IP on port 5000 and test login/session behavior. Do not test using public/untrusted Wi-Fi.

## Main routes

| Method | Route | Access | Purpose |
|---|---|---|---|
| GET | `/` | Public | Home or role-based redirect |
| GET/POST | `/register` | Public | Student account registration |
| GET/POST | `/login` | Public | Login |
| POST | `/logout` | Signed-in users | Logout |
| GET | `/student/dashboard` | Student | Own vehicle applications |
| GET | `/student/vehicles/new` | Verified student | Vehicle form |
| POST | `/student/vehicles` | Verified student | Submit vehicle |
| GET | `/student/vehicles/:id/edit` | Verified owner | Edit own vehicle |
| POST | `/student/vehicles/:id/edit` | Verified owner | Save edits; resets approval |
| GET | `/admin/dashboard` | Admin | Pending student verification, vehicle queue, and status counts |
| POST | `/admin/students/:id/verify` | Admin | Verify or reject a student account |
| POST | `/admin/vehicles/:id/review` | Admin | Approve/reject pending vehicle |
| GET | `/guard/check?plate=...` | Guard | Find vehicle and show recent logs |
| POST | `/guard/vehicles/:id/entry` | Guard | Record entry for approved vehicle |
| POST | `/guard/logs/:id/exit` | Guard | Close an open gate log |

## Database tables

- `tbl_users`: student, admin, and guard accounts; student accounts have Pending / Verified / Rejected manual verification status
- `tbl_vehicles`: plate, type, make/model, color, status, owner, reviewer
- `tbl_car_logs`: entry/exit timestamps and guard accounts

## School LAN deployment notes

- For a school LAN demonstration, run the app on a designated computer and let authorized devices connect using that computer's LAN IP and port 5000. Ensure Windows Firewall permits the port only on the trusted school network.
- The starter defaults to `secure: true` cookies when `NODE_ENV=production`, which requires HTTPS. Do not simply enable production mode for plain HTTP LAN use without configuring HTTPS, or login sessions will not work in browsers. For a controlled local LAN demo, leave `NODE_ENV` unset and use a strong `SESSION_SECRET`; for a real deployment, configure HTTPS and a persistent session store.
- A private GitHub repository is selected. Keep `.env` out of Git and invite only people who should access the source. GitHub itself does not host the running app or MySQL database.

## Before production or public deployment

This is a learning/MVP starter, not yet a production-ready campus security system.

- Replace the default session secret and seeded passwords.
- Use HTTPS and set `NODE_ENV=production`.
- Replace Express's default in-memory session store with a persistent session store.
- Add CSRF protection to POST forms.
- Add a proper account recovery and admin account-management process.
- Decide how to verify that a student ID belongs to a real enrolled student.
- Add database backups, audit/retention policy, and a process for correcting mistaken gate logs.
- Consider a database transaction or locking strategy to prevent simultaneous guards from opening duplicate active logs for one vehicle.
- Passes do not expire in this version. Decide later whether admins should revoke previously approved passes.
- Review applicable university privacy rules before collecting student and vehicle information.
- Restrict network access to the app and database appropriately; never expose MySQL publicly.
- Review dependency updates and security advisories before deployment.

## Known limitations in this starter

- No email verification, password reset, QR/RFID scan, pass expiration (per the current requirement), vehicle photo/document upload, export, or reporting yet.
- Students self-register with a typed university ID. An administrator must manually compare it with university records; the application does not connect to an official enrollment system.
- The session store is in memory and sessions are lost on server restart.
- The starter uses the server's local timezone for timestamps; configure the server/database timezone to the university's official timezone.
- A guard can close any open log after searching the vehicle. There is no separate shift/guard authorization workflow.
- The plate format check is generic and should be adapted to your university's local plate requirements.
