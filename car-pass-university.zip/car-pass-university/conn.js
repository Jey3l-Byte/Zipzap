require('dotenv').config();
const mysql = require('mysql');

const conn = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'university_car_pass',
    timezone: 'local',
    multipleStatements: false
});

conn.connect((err) => {
    if (err) {
        console.error('MySQL connection failed:', err.message);
        console.error('Check that MySQL is running and your .env settings are correct.');
        process.exit(1);
    }
    console.log('Connected to MySQL database.');
});

module.exports = conn;
