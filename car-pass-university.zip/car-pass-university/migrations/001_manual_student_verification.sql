-- Use this migration ONLY if you already created the original starter schema.
-- Back up your database first, select the correct database, and run this once.
USE university_car_pass;

ALTER TABLE tbl_users
    ADD COLUMN verification_status ENUM('Pending', 'Verified', 'Rejected') NOT NULL DEFAULT 'Pending' AFTER role,
    ADD COLUMN verified_by INT UNSIGNED NULL AFTER verification_status,
    ADD COLUMN verified_at DATETIME NULL AFTER verified_by,
    ADD COLUMN verification_note VARCHAR(500) NULL AFTER verified_at,
    ADD KEY idx_users_verification (role, verification_status),
    ADD CONSTRAINT fk_user_verifier FOREIGN KEY (verified_by) REFERENCES tbl_users(idnum);

-- Existing accounts are left Pending by default. An admin must manually verify
-- existing student accounts in the database before those students can register/edit vehicles.
-- Admin/guard accounts can continue to log in normally because the verification
-- status is enforced only for student vehicle operations.
